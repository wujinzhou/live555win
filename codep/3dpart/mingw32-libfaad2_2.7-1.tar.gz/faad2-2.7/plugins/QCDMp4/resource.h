//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by QCDMp4.rc
//
#define IDD_CONFIG                      102
#define IDC_TYPE                        1000
#define IDC_INFOTEXT                    1000
#define IDC_DURATION                    1001
#define IDC_BITRATE                     1002
#define IDC_SAMPLERATE                  1003
#define IDC_VTYPE                       1004
#define IDC_PRIORITY                    1004
#define IDC_VBITRATE                    1005
#define IDC_ERROR                       1005
#define IDC_VDURATION                   1006
#define IDC_16BITS                      1006
#define IDC_VSIZE                       1007
#define IDC_24BITS                      1007
#define IDC_CONVERT                     1007
#define IDC_VFPS                        1008
#define IDC_32BITS                      1008
#define IDC_CONVERT2                    1008
#define IDC_CHANNELS                    1009
#define IDC_24BITS2                     1009
#define IDC_16BITS_DITHERED             1009
#define IDC_CONVERT1                    1009
#define IDC_USERDATA                    1010
#define IDC_USEFORAAC                   1011
#define IDC_METACOMPILATION             1012
#define IDC_METANAME                    1013
#define IDC_METAARTIST                  1014
#define IDC_METAWRITER                  1015
#define IDC_METAALBUM                   1016
#define IDC_METACOMMENTS                1017
#define IDC_METAGENRE                   1018
#define IDC_METAYEAR                    1019
#define IDC_METATRACK1                  1020
#define IDC_METADISK1                   1021
#define IDC_METATEMPO                   1022
#define IDC_METATRACK2                  1023
#define IDC_METADISK2                   1024
#define IDC_STATIC1                     1025
#define IDC_STATIC2                     1026
#define IDC_STATIC3                     1027
#define IDC_STATIC4                     1028
#define IDC_STATIC5                     1029
#define IDC_STATIC6                     1030
#define IDC_STATIC7                     1031
#define IDC_STATIC8                     1032
#define IDC_STATIC9                     1033
#define IDC_STATIC10                    1034
#define IDC_STATIC11                    1035
#define IDC_STATIC12                    1036
#define IDC_DOWNMIX                     1038
#define IDC_VBR                         1039
#define IDC_TITLEFORMAT                 1040

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1041
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
